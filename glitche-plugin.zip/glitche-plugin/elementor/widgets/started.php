<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Glitche Started Widget.
 *
 * @since 1.0
 */
class Glitche_Started_Section_Widget extends Widget_Base {

	public function get_name() {
		return 'glitche-started-section';
	}

	public function get_title() {
		return esc_html__( 'Started Section', 'glitche-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'glitche-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'layout_tab',
			[
				'label' => esc_html__( 'Layout Version', 'glitche-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'	   => esc_html__( 'Layout', 'glitche-plugin' ),
				'type'		=> Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'  => __( 'Default', 'glitche-plugin' ),
					'creative'  => __( 'Creative', 'glitche-plugin' ),
				],
			]
		);

		$this->add_control(
			'logo',
			[
				'label'	   => esc_html__( 'Logo', 'glitche-plugin' ),
				'type'		=> Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no'  => __( 'No', 'glitche-plugin' ),
					'yes'  => __( 'Yes', 'glitche-plugin' ),
				],
			]
		);

		$this->add_control(
			'logo_image',
			[
				'label' => esc_html__( 'Logo', 'glitche-plugin' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => ['logo' => 'yes'],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_tab',
			[
				'label' => esc_html__( 'Title', 'glitche-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'	   => esc_html__( 'Title', 'glitche-plugin' ),
				'type'		=> Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'glitche-plugin' ),
				'default'	 => esc_html__( 'Title', 'glitche-plugin' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'	   => esc_html__( 'Title Tag', 'glitche-plugin' ),
				'type'		=> Controls_Manager::SELECT,
				'default' => 'h1',
				'options' => [
					'h1'  => __( 'H1', 'glitche-plugin' ),
					'h2' => __( 'H2', 'glitche-plugin' ),
					'div' => __( 'DIV', 'glitche-plugin' ),
				],
			]
		);

		$this->add_control(
			'title_glitch',
			[
				'label'	   => esc_html__( 'Title Glitch', 'glitche-plugin' ),
				'type'		=> Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no'  => __( 'No', 'glitche-plugin' ),
					'yes' => __( 'Yes', 'glitche-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subtitles_tab',
			[
				'label' => esc_html__( 'Subtitle', 'glitche-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'under_title',
			[
				'label'	   => esc_html__( 'Show under title', 'glitche-plugin' ),
				'type'		=> Controls_Manager::SELECT,
				'default' => 'subtitles',
				'options' => [
					'subtitles'  => __( 'Subtitles', 'glitche-plugin' ),
					'breadcrumbs' => __( 'Breadcrumbs', 'glitche-plugin' ),
					'hide' => __( 'Hide', 'glitche-plugin' ),
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'subtitle', [
				'label'	   => esc_html__( 'Subtitle', 'glitche-plugin' ),
				'type'		=> Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter subtitle', 'glitche-plugin' ),
				'default'	=> esc_html__( 'Enter subtitle', 'glitche-plugin' ),
			]
		);

		$this->add_control(
			'subtitles',
			[
				'label' => esc_html__( 'Subtitle Strings', 'glitche-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ subtitle }}}',
				'condition' => ['under_title' => 'subtitles']
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'background_tab',
			[
				'label' => esc_html__( 'Background', 'glitche-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'bg',
			[
				'label' => esc_html__( 'Background', 'glitche-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'  => esc_html__( 'None', 'glitche-plugin' ),
					'image'  => esc_html__( 'Image', 'glitche-plugin' ),
					'video' => esc_html__( 'Video', 'glitche-plugin' ),
					'color' => esc_html__( 'Color', 'glitche-plugin' ),
					'slideshow' => esc_html__( 'Slideshow', 'glitche-plugin' ),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'glitche-plugin' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => ['bg' => 'image']
			]
		);

		$this->add_control(
			'image_color',
			[
				'label'	 => esc_html__( 'Image Ovarlay', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .video-bg-mask' => 'background-color: {{VALUE}};',
				],
				'condition' => ['bg' => 'image']
			]
		);

		$this->add_control(
			'video',
			[
				'label' => esc_html__( 'Video Link', 'glitche-plugin' ),
				'type' => \Elementor\Controls_Manager::URL,
				'show_external' => false,
				'condition' => ['bg' => 'video']
			]
		);

		$this->add_control(
			'video_mute',
			[
				'label' => esc_html__( 'Mute', 'glitche-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'On', 'glitche-plugin' ),
				'label_off' => __( 'Off', 'glitche-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => ['bg' => 'video']
			]
		);

		$this->add_control(
			'video_color',
			[
				'label'	 => esc_html__( 'Video Ovarlay', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .video-bg-mask' => 'background-color: {{VALUE}};',
				],
				'condition' => ['bg' => 'video']
			]
		);

		$this->add_control(
			'color',
			[
				'label'	 => esc_html__( 'Background Color', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .video-bg' => 'background-color: {{VALUE}};',
				],
				'condition' => ['bg' => 'color']
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Choose Image', 'glitche-plugin' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'slideshow_items',
			[
				'label' => esc_html__( 'Slideshow Images', 'glitche-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'condition' => ['bg' => 'slideshow']
			]
		);

		$this->add_control(
			'slideshow_color',
			[
				'label'	 => esc_html__( 'Slideshow Ovarlay', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .video-bg-mask' => 'background-color: {{VALUE}};',
				],
				'condition' => ['bg' => 'slideshow']
			]
		);

		$this->add_control(
			'slideshow_autoplay',
			[
				'label'       => esc_html__( 'Slideshow Autoplay Speed', 'glitche-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( '5000', 'glitche-plugin' ),
				'default'	=> esc_html__( '5000', 'glitche-plugin' ),
				'condition' => ['bg' => 'slideshow']
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'	 => esc_html__( 'Title', 'glitche-plugin' ),
				'tab'	   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'	 => esc_html__( 'Color', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section.started .h-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'	 => 'title_typography',
				'selector' => '{{WRAPPER}} .section.started .h-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subtitle_styling',
			[
				'label'	 => esc_html__( 'Subtitle', 'glitche-plugin' ),
				'tab'	   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'	 => esc_html__( 'Color', 'glitche-plugin' ),
				'type'	  => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section.started .started-content .h-subtitle, {{WRAPPER}} .section.started .started-content .typed-subtitle, {{WRAPPER}} .section.started .started-content .typed-cursor' => 'color: {{VALUE}};',
					'' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'	 => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .section.started .started-content .h-subtitle, {{WRAPPER}} .section.started .started-content .typed-subtitle, {{WRAPPER}} .section.started .started-content .typed-cursor',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'title', 'basic' );
		?>

		<!-- Section Started -->
		<div class="section started<?php if ( $settings['bg'] == 'image' || $settings['bg'] == 'video' || $settings['bg'] == 'slideshow' || $settings['bg'] == 'color' ) : ?> background-enabled<?php endif; ?><?php if ( $settings['layout'] == 'creative' && $settings['layout'] ) : ?> layout-creative<?php endif; ?>">

			<?php if( $settings['bg'] == 'video' ) : ?>
			<div class="video-bg media-bg jarallax-video" data-jarallax-video="mp4:<?php echo esc_url( $settings['video']['url'] ); ?>" data-volume="<?php if ( ! $settings['video_mute'] ) : ?>100<?php endif; ?>">
				<div class="video-bg-mask"></div>
			</div>
			<?php endif; ?>

			<?php if( $settings['bg'] == 'image' && $settings['image'] ) :
				if ( $settings['image']['id'] ) {
					$image = wp_get_attachment_image_url( $settings['image']['id'], 'glitche_1920xAuto' );
				} else {
					$image = $settings['image']['url'];
				}
			?>
			<div class="video-bg media-bg jarallax">
				<img class="jarallax-img" src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
				<div class="video-bg-mask"></div>
			</div>
			<?php endif; ?>

			<?php if( $settings['bg'] == 'color' ) : ?>
			<div class="video-bg"></div>
			<?php endif; ?>

			<?php if( $settings['bg'] == 'slideshow' ) : ?>
			<div class="video-bg media-bg slideshow-bg">
				<div data-slick='{"arrows": 0, "autoplay": true, "autoplaySpeed": <?php echo esc_attr( $settings['slideshow_autoplay'] ); ?>, "dots": 0, "fade": true, "speed": 2000}'>
					<?php $i=0; foreach ( $settings['slideshow_items'] as $item ) : $i++; ?>
					<div class="jarallax">
						<img class="jarallax-img" src="<?php echo esc_attr( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
					</div>
					<?php endforeach; ?>
				</div>
				<div class="video-bg-mask"></div>
			</div>
			<?php endif; ?>

			<div class="centrize full-width">
				<div class="vertical-center">
					<div class="started-content">

						<?php if ( $settings['logo'] == 'yes' && $settings['logo_image'] ) : ?>
							<?php if( $settings['logo_image'] ) :
								if ( $settings['logo_image']['id'] ) {
									$image = wp_get_attachment_image_url( $settings['logo_image']['id'], 'glitche_680xAuto' );
								} else {
									$image = $settings['logo_image']['url'];
								}
							?>
							<div class="logo">
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
							</div>
							<?php endif; ?>
						<?php endif; ?>

						<?php if ( $settings['title'] ) : ?>
						<<?php echo esc_attr( $settings['title_tag'] ); ?> class="h-title <?php if ( $settings['title_glitch'] == 'yes' && $settings['title_glitch'] ) : ?>glitch-effect<?php endif; ?>" <?php if ( $settings['title_glitch'] == 'yes' && $settings['title_glitch'] ) : ?>data-text="<?php echo esc_attr( $settings['title'] ); ?>"<?php endif; ?>>
							<span {{{ view.getRenderAttributeString( 'title' ) }}}>
								<?php echo wp_kses_post( $settings['title'] ); ?>
							</span>
						</<?php echo esc_attr( $settings['title_tag'] ); ?>>
						<?php endif; ?>

						<?php if ( $settings['under_title'] == 'subtitles' && $settings['subtitles'] ) : ?>
						<div class="h-subtitles">
							<div class="h-subtitle typing-subtitle">
								<?php foreach ( $settings['subtitles'] as $index => $subtitle ) :
								$subtitle_text = $this->get_repeater_setting_key( 'subtitle', 'subtitles', $index );
								$this->add_inline_editing_attributes( $subtitle_text, 'none' );
								?>
								<p><?php echo wp_kses_post( $subtitle['subtitle'] ); ?></p>
								<?php endforeach; ?>
							</div>
							<span class="typed-subtitle"></span>
						</div>
						<?php endif; ?>

						<?php if ( $settings['under_title'] == 'breadcrumbs' ) : ?>
						<div class="h-subtitles">
							<div class="h-subtitle typing-bread">
								<?php glitche_breadcrumb(); ?>
							</div>
							<span class="typed-bread"></span>
						</div>
						<?php endif; ?>

					</div>
				</div>
			</div>
			<a href="#" class="mouse_btn" style="display: none;"><span class="ion ion-mouse"></span></a>
		</div>

		<?php
	}

}

Plugin::instance()->widgets_manager->register( new Glitche_Started_Section_Widget() );
